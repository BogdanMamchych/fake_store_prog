abstract class ItemListEvent {}

class FetchItemsEvent extends ItemListEvent {}
