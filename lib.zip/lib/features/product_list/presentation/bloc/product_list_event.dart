abstract class ProductListEvent {}

class FetchProductsEvent extends ProductListEvent {}
